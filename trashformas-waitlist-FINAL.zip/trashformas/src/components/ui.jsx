export function Logo({ light = false }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{ width:38, height:38, background:'linear-gradient(135deg,#2e8b2e,#56c456)', borderRadius:11, display:'flex', alignItems:'center', justifyContent:'center', fontSize:19, boxShadow:'0 2px 8px rgba(46,139,46,.3)', flexShrink:0 }}>♻️</div>
      <span style={{ fontFamily:'var(--ff-display)', fontWeight:900, fontSize:20, letterSpacing:-.5, color: light ? '#fff' : 'var(--ink)' }}>Trashformas</span>
    </div>
  )
}

export function BackBtn({ onClick, light = false }) {
  return (
    <button onClick={onClick} style={{ background:'none', border:'none', color: light ? 'rgba(255,255,255,.55)' : 'var(--ink50)', fontSize:13, fontWeight:500, cursor:'pointer', padding:0, display:'flex', alignItems:'center', gap:5, marginBottom:20 }}>
      ← Back
    </button>
  )
}

export function PrimaryBtn({ children, onClick, disabled, loading, style: s = {} }) {
  return (
    <button
      onClick={onClick} disabled={disabled || loading}
      onMouseEnter={e => { if (!disabled && !loading) e.currentTarget.style.transform='translateY(-2px)' }}
      onMouseLeave={e => { e.currentTarget.style.transform='translateY(0)' }}
      style={{ width:'100%', background: disabled ? 'var(--g200)' : 'linear-gradient(135deg,var(--g700),var(--g500))', color:'#fff', border:'none', borderRadius:'var(--r-md)', padding:'17px 22px', fontSize:16, fontWeight:700, cursor: disabled ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:10, boxShadow: disabled ? 'none' : 'var(--sh-green)', transition:'transform .15s, box-shadow .15s', ...s }}>
      {loading ? <><Spinner />&nbsp;Saving…</> : children}
    </button>
  )
}

export function GhostBtn({ children, onClick, style: s = {} }) {
  return (
    <button onClick={onClick}
      onMouseEnter={e => { e.currentTarget.style.background='rgba(255,255,255,.12)' }}
      onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,.07)' }}
      style={{ width:'100%', background:'rgba(255,255,255,.07)', color:'rgba(255,255,255,.85)', border:'1px solid rgba(255,255,255,.14)', borderRadius:'var(--r-md)', padding:'16px 22px', fontSize:15, fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'space-between', transition:'background .15s', ...s }}>
      {children}
    </button>
  )
}

export function Card({ children, style: s = {} }) {
  return <div style={{ background:'var(--white)', border:'1px solid rgba(0,0,0,.07)', borderRadius:'var(--r-md)', padding:20, boxShadow:'var(--sh-sm)', ...s }}>{children}</div>
}

export function SectionLabel({ children }) {
  return <div style={{ fontSize:10.5, fontWeight:700, letterSpacing:1.8, textTransform:'uppercase', color:'var(--ink50)', marginBottom:11 }}>{children}</div>
}

export function LiveBadge() {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:6, background:'rgba(76,175,80,.15)', border:'1px solid rgba(76,175,80,.3)', borderRadius:100, padding:'5px 12px', fontSize:11, color:'#9fdb9f', fontWeight:500 }}>
      <div style={{ width:6, height:6, background:'#4caf50', borderRadius:'50%', animation:'pulseDot 2s infinite' }} />
      Launching Soon
    </div>
  )
}

export function Spinner({ size = 16 }) {
  return <div style={{ width:size, height:size, border:'2px solid rgba(255,255,255,.3)', borderTopColor:'#fff', borderRadius:'50%', animation:'spin .7s linear infinite', flexShrink:0 }} />
}

export function Toast({ msg }) {
  if (!msg) return null
  return (
    <div style={{ position:'fixed', bottom:24, left:'50%', transform:'translateX(-50%)', background:'var(--ink)', color:'#fff', borderRadius:'var(--r-sm)', padding:'13px 22px', fontSize:13.5, fontWeight:500, boxShadow:'0 8px 32px rgba(0,0,0,.22)', zIndex:9999, whiteSpace:'nowrap', animation:'fadeUp .3s cubic-bezier(.22,1,.36,1)' }}>
      {msg}
    </div>
  )
}
