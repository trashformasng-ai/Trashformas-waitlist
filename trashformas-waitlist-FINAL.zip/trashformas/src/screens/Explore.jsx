import { useState } from 'react'
import { Logo, BackBtn, PrimaryBtn, Card, SectionLabel, Toast } from '../components/ui.jsx'

const STATIONS = [
  { id:1, name:'Trashformas Hub — Yaba',          lat:6.5158, lng:3.3724, address:'14 Herbert Macaulay Way, Yaba' },
  { id:2, name:'Trashformas Hub — Surulere',      lat:6.4969, lng:3.3481, address:'22 Bode Thomas St, Surulere' },
  { id:3, name:'Trashformas Hub — Ikeja',         lat:6.5954, lng:3.3378, address:'7 Adeniyi Jones Ave, Ikeja' },
  { id:4, name:'Trashformas Hub — Lekki Phase 1', lat:6.4314, lng:3.4748, address:'5 Admiralty Way, Lekki' },
  { id:5, name:'Trashformas Hub — Ikorodu',       lat:6.6188, lng:3.5091, address:'Ikorodu Rd, Junction Bus Stop' },
]

function haversineKm(a,b,c,d){const R=6371,dL=(c-a)*Math.PI/180,dl=(d-b)*Math.PI/180,x=Math.sin(dL/2)**2+Math.cos(a*Math.PI/180)*Math.cos(c*Math.PI/180)*Math.sin(dl/2)**2;return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))}
function travelMins(km){ return Math.round((km/25)*60)+5 }
function fmtMins(m){ return m<60?`${m} min`:`${Math.floor(m/60)}h ${m%60}min` }

const PRICES = { '6kg':6090, '12.5kg':12688, '25kg':25375 }
const MAX_DAILY = 2
const RES_KEY   = 'tf_reservations'

function todayCount(){ try{ const d=JSON.parse(localStorage.getItem(RES_KEY)||'{}'); return d[new Date().toDateString()]||0 }catch{return 0} }
function incRes(){ const t=new Date().toDateString(),d=JSON.parse(localStorage.getItem(RES_KEY)||'{}'); d[t]=(d[t]||0)+1; localStorage.setItem(RES_KEY,JSON.stringify(d)) }

function ReservationDemo() {
  const [step,setStep]       = useState('form')
  const [size,setSize]       = useState('6kg')
  const [qty,setQty]         = useState(1)
  const [station,setStation] = useState(null)
  const [distKm,setDistKm]   = useState(null)
  const [travel,setTravel]   = useState(null)
  const [resCount,setResCount] = useState(todayCount)
  const [toast,setToast]     = useState('')

  const showToast = m => { setToast(m); setTimeout(()=>setToast(''),3500) }
  const remaining = MAX_DAILY - resCount
  const total = PRICES[size] * qty

  const findStation = () => {
    if (remaining<=0){ showToast(`⛔ Daily limit reached — max ${MAX_DAILY} reservations/day`); return }
    setStep('locating')
    const resolve = (lat,lng) => {
      let nearest=null,minD=Infinity
      STATIONS.forEach(s=>{ const d=haversineKm(lat,lng,s.lat,s.lng); if(d<minD){minD=d;nearest=s} })
      setStation(nearest); setDistKm(minD.toFixed(1)); setTravel(travelMins(minD)); setStep('result')
    }
    navigator.geolocation.getCurrentPosition(
      p=>resolve(p.coords.latitude,p.coords.longitude),
      ()=>resolve(6.5244,3.3792),
      {timeout:8000}
    )
  }

  const confirm = () => { incRes(); setResCount(c=>c+1); setStep('confirmed') }

  const statBtn = (label, active, onClick) => (
    <button key={label} onClick={onClick} style={{ flex:1, background: active ? 'var(--g800)' : '#fff', color: active ? '#fff' : 'var(--ink)', border:`2px solid ${active?'var(--g700)':'#e0e0e0'}`, borderRadius:'var(--r-sm)', padding:'13px 6px', cursor:'pointer', textAlign:'center', fontFamily:'inherit', transition:'all .15s' }}>
      <div style={{ fontFamily:'var(--ff-display)', fontWeight:900, fontSize:17, marginBottom:3 }}>{label}</div>
      <div style={{ fontSize:11, opacity:.7 }}>₦{PRICES[label].toLocaleString()}</div>
    </button>
  )

  return (
    <div style={{ padding:'22px 0 0' }}>
      {/* Daily limit tracker */}
      <div style={{ display:'flex', gap:10, marginBottom:20 }}>
        {[...Array(MAX_DAILY)].map((_,i)=>{
          const used=i<resCount
          return <div key={i} style={{ flex:1, background:used?'#fee2e2':'#e8f5e9', border:`1px solid ${used?'#fca5a5':'#a7f3d0'}`, borderRadius:12, padding:'12px 10px', textAlign:'center' }}>
            <div style={{ fontSize:20, marginBottom:3 }}>{used?'🔴':'🟢'}</div>
            <div style={{ fontSize:10, fontWeight:700, color:used?'#b91c1c':'#166534' }}>{used?'Used':'Available'}</div>
          </div>
        })}
        <div style={{ flex:2.5, background:'#fff', border:'1px solid #ececec', borderRadius:12, padding:'12px 14px' }}>
          <div style={{ fontSize:11, color:'var(--ink50)', marginBottom:3 }}>Today's reservations</div>
          <div style={{ fontFamily:'var(--ff-display)', fontWeight:900, fontSize:18 }}>{resCount} <span style={{ fontSize:13, opacity:.5 }}>/ {MAX_DAILY}</span></div>
          <div style={{ fontSize:10.5, color:remaining>0?'var(--g700)':'#b91c1c', marginTop:2 }}>{remaining>0?`${remaining} remaining today`:'Resets tomorrow'}</div>
        </div>
      </div>

      {step==='form' && <>
        <SectionLabel>🔵 Cylinder Size</SectionLabel>
        <div style={{ display:'flex', gap:8, marginBottom:20 }}>
          {Object.keys(PRICES).map(sz => statBtn(sz, size===sz, ()=>setSize(sz)))}
        </div>
        <SectionLabel>🔢 Quantity</SectionLabel>
        <Card style={{ marginBottom:20, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <button onClick={()=>setQty(q=>Math.max(1,q-1))} disabled={qty<=1} style={{ width:44,height:44,borderRadius:11,border:'1.5px solid #e0e0e0',background:'#f5f5f5',fontSize:22,cursor:qty>1?'pointer':'not-allowed',display:'flex',alignItems:'center',justifyContent:'center',opacity:qty<=1?.4:1 }}>−</button>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontFamily:'var(--ff-display)', fontWeight:900, fontSize:32, lineHeight:1 }}>{qty}</div>
            <div style={{ fontSize:12, color:'var(--ink50)' }}>cylinder{qty>1?'s':''}</div>
          </div>
          <button onClick={()=>setQty(q=>Math.min(remaining,q+1))} disabled={qty>=remaining} style={{ width:44,height:44,borderRadius:11,border:'1.5px solid var(--g200)',background:'var(--g50)',fontSize:22,cursor:qty<remaining?'pointer':'not-allowed',color:'var(--g700)',display:'flex',alignItems:'center',justifyContent:'center',opacity:qty>=remaining?.4:1 }}>+</button>
        </Card>
        <Card style={{ background:'var(--g50)', border:'1px solid var(--g100)', marginBottom:22 }}>
          <div style={{ display:'flex',justifyContent:'space-between',marginBottom:8,fontSize:14 }}>
            <span style={{ color:'var(--ink50)' }}>Cylinder</span>
            <span style={{ fontWeight:600 }}>{qty}× {size} @ ₦{PRICES[size].toLocaleString()}</span>
          </div>
          <div style={{ display:'flex',justifyContent:'space-between',paddingTop:10,borderTop:'1px solid var(--g100)' }}>
            <span style={{ fontWeight:700,fontSize:15 }}>Total</span>
            <span style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:20,color:'var(--g800)' }}>₦{total.toLocaleString()}</span>
          </div>
        </Card>
        <PrimaryBtn onClick={findStation} disabled={remaining<=0}>
          <span>📍 Find Nearest Pickup Station</span><span>→</span>
        </PrimaryBtn>
      </>}

      {step==='locating' && (
        <div style={{ display:'flex',flexDirection:'column',alignItems:'center',padding:'50px 0',textAlign:'center' }}>
          <div style={{ width:60,height:60,border:'4px solid var(--g100)',borderTopColor:'var(--g600)',borderRadius:'50%',animation:'spin 1s linear infinite',marginBottom:22 }} />
          <div style={{ fontFamily:'var(--ff-display)',fontWeight:700,fontSize:18,marginBottom:8 }}>Finding your location…</div>
          <div style={{ fontSize:13.5,color:'var(--ink50)' }}>Locating your nearest pickup station</div>
        </div>
      )}

      {step==='result' && station && <>
        <div style={{ background:'linear-gradient(135deg,var(--g900),var(--g700))', borderRadius:'var(--r-md)', padding:22, color:'#fff', marginBottom:18 }}>
          <div style={{ fontSize:10,opacity:.6,textTransform:'uppercase',letterSpacing:1.2,marginBottom:12,fontWeight:700 }}>📍 Nearest Pickup Station</div>
          <div style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:18,marginBottom:4 }}>{station.name}</div>
          <div style={{ fontSize:13,opacity:.75,marginBottom:18 }}>{station.address}</div>
          <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10 }}>
            {[['📏',distKm+' km','distance'],['🚗',fmtMins(travel-5),'drive time'],['⏱️',fmtMins(travel),'incl. 5-min buffer']].map(([icon,val,lbl])=>(
              <div key={lbl} style={{ background:'rgba(255,255,255,.12)',borderRadius:11,padding:'12px 8px',textAlign:'center' }}>
                <div style={{ fontSize:18,marginBottom:4 }}>{icon}</div>
                <div style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:14,lineHeight:1,marginBottom:3 }}>{val}</div>
                <div style={{ fontSize:9.5,opacity:.6 }}>{lbl}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ background:'var(--amberL)',border:'1px solid #fcd34d',borderRadius:12,padding:'12px 16px',marginBottom:18,fontSize:13,color:'#78350f',lineHeight:1.65 }}>
          ⏱️ <strong>5-minute buffer included</strong> — accounts for possible holdups so your cylinder is ready when you arrive.
        </div>
        <Card style={{ background:'var(--g50)',border:'1px solid var(--g100)',marginBottom:20 }}>
          <div style={{ fontFamily:'var(--ff-display)',fontWeight:700,fontSize:15,marginBottom:14 }}>Reservation Summary</div>
          {[['Cylinder',`${qty}× ${size}`],['Price per cylinder',`₦${PRICES[size].toLocaleString()}`],['Total payable',`₦${total.toLocaleString()}`],['Pickup station',station.name],['Estimated arrival',`${fmtMins(travel)} from now`]].map(([k,v])=>(
            <div key={k} style={{ display:'flex',justifyContent:'space-between',marginBottom:10,fontSize:13 }}>
              <span style={{ color:'var(--ink50)' }}>{k}</span>
              <span style={{ fontWeight:600,textAlign:'right',maxWidth:'55%' }}>{v}</span>
            </div>
          ))}
        </Card>
        <div style={{ display:'flex',flexDirection:'column',gap:10 }}>
          <PrimaryBtn onClick={confirm}>✅ Confirm Reservation</PrimaryBtn>
          <button onClick={()=>setStep('form')} style={{ background:'none',border:'1px solid #e0e0e0',borderRadius:'var(--r-md)',padding:15,fontSize:14,fontWeight:600,color:'var(--ink50)',cursor:'pointer',width:'100%' }}>← Change Order</button>
        </div>
      </>}

      {step==='confirmed' && (
        <div style={{ textAlign:'center',padding:'40px 20px' }}>
          <div style={{ width:72,height:72,background:'linear-gradient(135deg,var(--g700),var(--g500))',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:32,margin:'0 auto 22px',boxShadow:'var(--sh-greenL)' }}>⛽</div>
          <div style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:24,marginBottom:10 }}>Cylinder Reserved!</div>
          <p style={{ fontSize:14,color:'var(--ink50)',lineHeight:1.7,marginBottom:24 }}>
            Your {qty}× {size} cylinder{qty>1?'s are':' is'} reserved at <strong>{station?.name}</strong>. Head over — estimated arrival <strong>{fmtMins(travel)} from now</strong>.
          </p>
          <div style={{ background:'var(--g50)',border:'1px solid var(--g100)',borderRadius:12,padding:'14px 18px',marginBottom:22,fontSize:13,color:'var(--ink50)' }}>
            🔁 Reservations used today: <strong style={{ color:'var(--g800)' }}>{resCount} / {MAX_DAILY}</strong>
          </div>
          <button onClick={()=>setStep('form')} style={{ width:'100%',background:'var(--g50)',border:'1px solid var(--g100)',borderRadius:'var(--r-md)',padding:15,fontSize:14,fontWeight:600,cursor:'pointer',color:'var(--g800)' }}>
            Make Another Reservation
          </button>
        </div>
      )}
      <Toast msg={toast} />
    </div>
  )
}

export default function Explore({ goTo }) {
  const [tab, setTab] = useState('features')

  const features = [
    { icon:'📱', bg:'#e8f5e9', title:'Reserve a Cylinder',        desc:'Order a pre-filled biogas cylinder via the app — max 2 reservations per day per customer.', live:true },
    { icon:'📍', bg:'#e0f2fe', title:'GPS Pickup Station Finder',  desc:'Your GPS locates the nearest station, calculates travel time, and adds a 5-minute holdups buffer.', live:true },
    { icon:'📊', bg:'#fef9c3', title:'Usage Tracker',              desc:'Track monthly consumption and see CO₂ savings vs traditional LPG.', live:false },
    { icon:'♻️', bg:'#ede9fe', title:'Waste Drop-off & Credits',   desc:'Find organic waste collection points and earn gas credits toward your next cylinder.', live:false },
    { icon:'💳', bg:'#fce7f3', title:'Subscription Plans',         desc:'Lock in ₦1,015/kg with a monthly plan — never run out of gas again.', live:false },
    { icon:'📣', bg:'#e8f5e9', title:'Refer & Earn',               desc:'Invite friends and earn free gas credits for every successful referral.', live:false },
  ]

  return (
    <div style={{ minHeight:'100vh', background:'var(--cream)', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{ background:'#0e1a0e', padding:'26px 24px 26px', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute',inset:0,background:'radial-gradient(ellipse 65% 100% at 92% 50%, rgba(46,139,46,.25) 0%, transparent 60%)',pointerEvents:'none' }} />
        <div style={{ position:'relative',zIndex:1 }}>
          <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:20 }}>
            <Logo light />
            <BackBtn onClick={()=>goTo('welcome')} light />
          </div>
          <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8 }}>
            {[['₦1,015','per kg'],['+20%','cook time'],['2/day','max reserve']].map(([v,l])=>(
              <div key={l} style={{ background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.09)',borderRadius:11,padding:'12px 8px',textAlign:'center' }}>
                <div style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:15,color:'var(--g300)',lineHeight:1,marginBottom:3 }}>{v}</div>
                <div style={{ fontSize:9.5,color:'rgba(255,255,255,.42)' }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background:'#fff',borderBottom:'1px solid #ececec',padding:'0 24px' }}>
        <div style={{ display:'flex',maxWidth:480,margin:'0 auto' }}>
          {[['features','🛠 Features'],['reserve','📍 Reserve Demo']].map(([t,lbl])=>(
            <button key={t} onClick={()=>setTab(t)} style={{ flex:1,background:'none',border:'none',borderBottom:`2.5px solid ${tab===t?'var(--g600)':'transparent'}`,padding:'15px 8px',fontSize:14,fontWeight:600,color:tab===t?'var(--g700)':'var(--ink50)',cursor:'pointer',transition:'all .15s' }}>{lbl}</button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ flex:1,overflowY:'auto',padding:'22px 20px 56px',maxWidth:480,margin:'0 auto',width:'100%' }}>
        {tab==='features' && <>
          <SectionLabel>⛽ Gas Pricing</SectionLabel>
          <div style={{ background:'linear-gradient(135deg,var(--g900),var(--g700))',borderRadius:'var(--r-md)',padding:22,color:'#fff',marginBottom:22 }}>
            <div style={{ fontSize:10,opacity:.6,textTransform:'uppercase',letterSpacing:.8,marginBottom:14,fontWeight:700 }}>Trashformas vs Traditional LPG</div>
            <div style={{ display:'flex',gap:20 }}>
              {[['Trashformas Biogas','₦1,015','per kg · from organic waste'],['Traditional LPG','~₦1,200+','market price (rising)']].map(([lbl,price,note])=>(
                <div key={lbl} style={{ flex:1 }}>
                  <div style={{ fontSize:10,opacity:.55,marginBottom:6,textTransform:'uppercase',letterSpacing:.5 }}>{lbl}</div>
                  <div style={{ fontFamily:'var(--ff-display)',fontWeight:900,fontSize:22,lineHeight:1,marginBottom:4 }}>{price}</div>
                  <div style={{ fontSize:11,opacity:.6,lineHeight:1.4 }}>{note}</div>
                </div>
              ))}
            </div>
            <div style={{ background:'rgba(255,255,255,.13)',borderRadius:8,padding:'6px 12px',fontSize:11.5,fontWeight:600,display:'inline-block',marginTop:16 }}>
              💡 +20% more cook time = real savings beyond the price tag
            </div>
          </div>

          <SectionLabel>🛠 App Features</SectionLabel>
          <div style={{ display:'flex',flexDirection:'column',gap:10,marginBottom:24 }}>
            {features.map(({icon,bg,title,desc,live})=>(
              <Card key={title} style={{ display:'flex',gap:14,alignItems:'flex-start' }}>
                <div style={{ width:48,height:48,minWidth:48,background:bg,borderRadius:13,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22 }}>{icon}</div>
                <div>
                  <div style={{ fontFamily:'var(--ff-display)',fontWeight:700,fontSize:15,marginBottom:4 }}>{title}</div>
                  <div style={{ fontSize:13,color:'var(--ink50)',lineHeight:1.55 }}>{desc}</div>
                  <span style={{ display:'inline-block',fontSize:10,fontWeight:700,background:live?'#dcfce7':'var(--amberL)',color:live?'#166534':'#92400e',borderRadius:6,padding:'3px 8px',marginTop:8 }}>{live?'✅ In Demo':'Coming Soon'}</span>
                </div>
              </Card>
            ))}
          </div>
          <PrimaryBtn onClick={()=>goTo('waitlist')}>
            <span>Join the Waitlist</span><span>→</span>
          </PrimaryBtn>
        </>}

        {tab==='reserve' && <ReservationDemo />}
      </div>
    </div>
  )
}
