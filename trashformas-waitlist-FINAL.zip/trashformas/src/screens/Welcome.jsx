import { Logo, LiveBadge, PrimaryBtn, GhostBtn } from '../components/ui.jsx'

export default function Welcome({ goTo }) {
  return (
    <div style={{ minHeight:'100vh', background:'#0e1a0e', color:'#fff', display:'flex', flexDirection:'column', position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse 75% 55% at 12% 22%, rgba(46,139,46,.38) 0%, transparent 55%), radial-gradient(ellipse 55% 65% at 88% 78%, rgba(26,92,26,.32) 0%, transparent 55%)', pointerEvents:'none' }} />
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', opacity:.03, pointerEvents:'none' }}>
        <filter id="gr"><feTurbulence type="fractalNoise" baseFrequency="0.75" numOctaves="4" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/></filter>
        <rect width="100%" height="100%" filter="url(#gr)" />
      </svg>

      <div style={{ position:'relative', zIndex:1, flex:1, display:'flex', flexDirection:'column', padding:'0 24px', maxWidth:480, margin:'0 auto', width:'100%' }}>

        {/* Nav */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', paddingTop:28 }}>
          <Logo light />
          <LiveBadge />
        </div>

        {/* Hero */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', justifyContent:'center', padding:'28px 0 16px' }}>

          <div className="fu fu1" style={{ fontSize:11, letterSpacing:2.5, textTransform:'uppercase', color:'var(--g300)', fontWeight:600, marginBottom:20, display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:28, height:1, background:'var(--g400)' }} /> Rethinking Waste
          </div>

          <h1 className="fu fu2" style={{ fontSize:'clamp(34px,9vw,50px)', fontWeight:900, lineHeight:1.04, letterSpacing:-2, marginBottom:20 }}>
            Waste into<br />
            <span style={{ background:'linear-gradient(95deg,#56c456,#aeeaae)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>cooking gas.</span>
            <br />Cleaner & cheaper.
          </h1>

          <p className="fu fu3" style={{ fontSize:15, lineHeight:1.75, color:'rgba(255,255,255,.58)', marginBottom:28, fontWeight:300 }}>
            Biogas converted from organic waste — available at{' '}
            <strong style={{ color:'var(--g300)', fontWeight:600 }}>₦1,015/kg</strong>.
            Reserve a pre-filled cylinder via the app, collect from your nearest
            station, and enjoy{' '}
            <strong style={{ color:'var(--g300)', fontWeight:600 }}>up to 20% more cook time</strong>{' '}
            per kg than traditional LPG.
          </p>

          {/* Stats */}
          <div className="fu fu4" style={{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(76,175,80,.18)', borderRadius:18, padding:20, marginBottom:24 }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:'uppercase', color:'var(--g300)', marginBottom:16, opacity:.8 }}>⚡ Why Trashformas gas is better</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10 }}>
              {[['₦1,015','per kg'],['+20%','more cook time'],['🌱','carbon-negative']].map(([v,d],i) => (
                <div key={i} style={{ background:'rgba(76,175,80,.09)', border:'1px solid rgba(76,175,80,.12)', borderRadius:12, padding:'14px 8px', textAlign:'center' }}>
                  <div style={{ fontFamily: i===2 ? 'inherit' : 'var(--ff-display)', fontWeight:900, fontSize: i===2 ? 24 : 18, color:'var(--g400)', lineHeight:1, marginBottom:5 }}>{v}</div>
                  <div style={{ fontSize:10, color:'rgba(255,255,255,.42)', lineHeight:1.35 }}>{d}</div>
                </div>
              ))}
            </div>
          </div>

          {/* How it works */}
          <div className="fu fu5" style={{ marginBottom:28 }}>
            <div style={{ fontSize:10, fontWeight:700, letterSpacing:2, textTransform:'uppercase', color:'var(--g300)', marginBottom:14, opacity:.8 }}>📱 How it works</div>
            {[
              'Reserve a pre-filled cylinder via the app (max 2/day)',
              'App finds your nearest pickup station via GPS',
              'See your estimated travel time + 5-min buffer',
              'Drive to the station & collect your cylinder',
            ].map((t,i) => (
              <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:12, marginBottom:10 }}>
                <div style={{ width:22, height:22, minWidth:22, background:'rgba(76,175,80,.18)', border:'1px solid rgba(76,175,80,.35)', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:800, color:'var(--g400)' }}>{i+1}</div>
                <span style={{ fontSize:13.5, color:'rgba(255,255,255,.62)', lineHeight:1.55 }}>{t}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTAs */}
        <div style={{ paddingBottom:40, display:'flex', flexDirection:'column', gap:12 }}>
          <PrimaryBtn onClick={() => goTo('waitlist')}>
            <span>Join the Waitlist</span><span style={{ fontSize:18 }}>→</span>
          </PrimaryBtn>
          <GhostBtn onClick={() => goTo('explore')}>
            <span>Explore the App</span><span>↗</span>
          </GhostBtn>
        </div>
      </div>
    </div>
  )
}
