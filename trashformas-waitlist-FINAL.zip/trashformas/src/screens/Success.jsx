import { PrimaryBtn, GhostBtn } from '../components/ui.jsx'

export default function Success({ goTo, position }) {
  return (
    <div style={{ minHeight:'100vh', background:'#0e1a0e', display:'flex', alignItems:'center', justifyContent:'center', padding:'40px 24px', position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse 70% 55% at 15% 28%, rgba(46,139,46,.38) 0%, transparent 55%), radial-gradient(ellipse 50% 50% at 85% 72%, rgba(26,92,26,.30) 0%, transparent 55%)', pointerEvents:'none' }} />
      <div style={{ position:'relative', zIndex:1, maxWidth:360, width:'100%', textAlign:'center', color:'#fff' }}>

        <div style={{ width:80, height:80, background:'linear-gradient(135deg,var(--g700),var(--g500))', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:36, margin:'0 auto 28px', boxShadow:'var(--sh-greenL)', animation:'fadeUp .5s cubic-bezier(.22,1,.36,1)' }}>✅</div>

        <h2 style={{ fontSize:32, fontWeight:900, letterSpacing:-1, marginBottom:12, animation:'fadeUp .5s .1s cubic-bezier(.22,1,.36,1) both' }}>You're on the list!</h2>

        <p style={{ fontSize:15, color:'rgba(255,255,255,.55)', lineHeight:1.7, marginBottom:28, fontWeight:300, animation:'fadeUp .5s .18s cubic-bezier(.22,1,.36,1) both' }}>
          Welcome to the Trashformas family. We'll reach out via WhatsApp as soon as we launch in your area — get ready to reserve your first pre-filled biogas cylinder!
        </p>

        {position && (
          <div style={{ background:'rgba(76,175,80,.1)', border:'1px solid rgba(76,175,80,.22)', borderRadius:'var(--r-md)', padding:'18px 22px', marginBottom:16, animation:'fadeUp .5s .25s cubic-bezier(.22,1,.36,1) both' }}>
            <div style={{ fontSize:10.5, letterSpacing:2, textTransform:'uppercase', color:'var(--g300)', marginBottom:8, fontWeight:600 }}>Your Waitlist Position</div>
            <div style={{ fontFamily:'var(--ff-display)', fontSize:40, fontWeight:900, lineHeight:1 }}>#{position}</div>
          </div>
        )}

        <div style={{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.08)', borderRadius:'var(--r-md)', padding:'14px 18px', marginBottom:28, fontSize:13, color:'rgba(255,255,255,.5)', lineHeight:1.65, animation:'fadeUp .5s .32s cubic-bezier(.22,1,.36,1) both' }}>
          📬 Your signup was saved to Forminit and a confirmation email sent via Web3Forms.
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:10, animation:'fadeUp .5s .38s cubic-bezier(.22,1,.36,1) both' }}>
          <PrimaryBtn onClick={() => goTo('explore')}>
            <span>Explore the App</span><span>→</span>
          </PrimaryBtn>
          <GhostBtn onClick={() => goTo('welcome')}>
            <span>← Back to Home</span><span />
          </GhostBtn>
        </div>
      </div>
    </div>
  )
}
