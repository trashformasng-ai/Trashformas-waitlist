import { useState } from 'react'
import { BackBtn, PrimaryBtn, Card, SectionLabel, Toast } from '../components/ui.jsx'

// ─────────────────────────────────────────────────────
//  LIVE ENDPOINTS — DO NOT CHANGE
//  Forminit:   https://forminit.com/f/463mmpz58h6
//  Web3Forms:  access key 20e4afa7-ff1a-46e8-a900-8da9ddca94c5
// ─────────────────────────────────────────────────────
const FORMINIT_URL = 'https://forminit.com/f/463mmpz58h6'
const WEB3_KEY     = '20e4afa7-ff1a-46e8-a900-8da9ddca94c5'
const GAS_PRICE    = 1015

export default function Waitlist({ goTo, onSuccess }) {
  const [form, setForm] = useState({ name:'', email:'', whatsapp:'', location:'', usage:'', source:'' })
  const [kg, setKg]         = useState(12)
  const [loading, setLoading] = useState(false)
  const [toast, setToast]   = useState('')

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const showToast = (m) => { setToast(m); setTimeout(() => setToast(''), 3500) }

  const monthlyCost   = Math.round(kg * 0.833 * GAS_PRICE)
  const equivalentLPG = Math.round(kg * 1.2)

  const handleSubmit = async () => {
    if (!form.name.trim())         return showToast('⚠️ Please enter your name')
    if (!form.email.includes('@')) return showToast('⚠️ Please enter a valid email')
    if (form.whatsapp.length < 7)  return showToast('⚠️ Please enter your WhatsApp number')
    if (!form.location.trim())     return showToast('⚠️ Please enter your location')

    setLoading(true)

    const payload = {
      name:         form.name,
      email:        form.email,
      whatsapp:     '+234' + form.whatsapp,
      location:     form.location,
      gas_usage:    form.usage  || 'Not specified',
      heard_from:   form.source || 'Not specified',
      est_kg_month: kg + 'kg/month',
      est_cost:     '₦' + monthlyCost.toLocaleString() + '/month',
      submitted_at: new Date().toISOString(),
    }

    try {
      // Fire both simultaneously — dual backup
      const [forminitRes, web3Res] = await Promise.allSettled([

        // ── PRIMARY: Forminit (dashboard + inbox + CSV export) ──
        fetch(FORMINIT_URL, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body:    JSON.stringify(payload),
        }),

        // ── BACKUP: Web3Forms (instant email to trashformasng@gmail.com) ──
        fetch('https://api.web3forms.com/submit', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body:    JSON.stringify({
            access_key:   WEB3_KEY,
            subject:      `New Waitlist Signup — ${form.name}`,
            from_name:    'Trashformas Waitlist',
            ...payload,
          }),
        }),

      ])

      const forminitOk = forminitRes.status === 'fulfilled' && forminitRes.value?.ok
      const web3Ok     = web3Res.status     === 'fulfilled' && web3Res.value?.ok

      if (forminitOk || web3Ok) {
        // Increment local position counter
        const prev = parseInt(localStorage.getItem('tf_count') || '0', 10)
        const pos  = prev + 1
        localStorage.setItem('tf_count', String(pos))
        onSuccess(pos)
      } else {
        showToast('⚠️ Submission failed — please check your connection and try again')
      }

    } catch {
      showToast('⚠️ Network error — please try again')
    } finally {
      setLoading(false)
    }
  }

  // ── Shared input style ──
  const inp = {
    width:'100%', background:'var(--g50)', border:'1.5px solid var(--g100)',
    borderRadius:'var(--r-sm)', padding:'13px 15px', fontSize:15,
    color:'var(--ink)', outline:'none', boxSizing:'border-box', transition:'border-color .15s',
  }
  const lbl = { display:'block', fontSize:13, fontWeight:600, color:'var(--ink80)', marginBottom:7 }

  return (
    <div style={{ minHeight:'100vh', background:'var(--cream)', display:'flex', flexDirection:'column' }}>

      {/* Dark header */}
      <div style={{ background:'#0e1a0e', padding:'26px 24px 42px', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse 65% 100% at 92% 50%, rgba(46,139,46,.25) 0%, transparent 60%)', pointerEvents:'none' }} />
        <div style={{ position:'relative', zIndex:1 }}>
          <BackBtn onClick={() => goTo('welcome')} light />
          <h2 style={{ fontSize:28, fontWeight:900, color:'#fff', letterSpacing:-.8, marginBottom:6 }}>Join the Waitlist</h2>
          <p style={{ fontSize:14, color:'rgba(255,255,255,.5)', fontWeight:300 }}>Be first when we launch in your area.</p>
        </div>
      </div>

      <div style={{ flex:1, overflowY:'auto', padding:'24px 20px 60px', maxWidth:480, margin:'0 auto', width:'100%' }}>

        {/* Live status badge */}
        <div style={{ display:'flex', alignItems:'flex-start', gap:10, background:'#dcfce7', border:'1px solid #86efac', borderRadius:13, padding:'13px 16px', marginBottom:20, fontSize:13, color:'#166534', lineHeight:1.6 }}>
          <span style={{ fontSize:17, flexShrink:0 }}>✅</span>
          <div>
            <strong>Live data collection active.</strong> Signups go to{' '}
            <strong>Forminit dashboard</strong> and are emailed to you instantly via <strong>Web3Forms</strong> — dual backup on every submission.
          </div>
        </div>

        {/* Price banner */}
        <div style={{ background:'linear-gradient(135deg,var(--g900),var(--g700))', borderRadius:'var(--r-md)', padding:20, marginBottom:22, display:'flex', alignItems:'center', gap:16 }}>
          <div style={{ width:50, height:50, minWidth:50, background:'rgba(255,255,255,.12)', borderRadius:14, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>⛽</div>
          <div style={{ color:'#fff' }}>
            <div style={{ fontFamily:'var(--ff-display)', fontSize:22, fontWeight:900, lineHeight:1, marginBottom:5 }}>₦1,015/kg</div>
            <div style={{ fontSize:12, opacity:.72, lineHeight:1.55 }}>
              Introductory price · Reserve via app · Collect at nearest station<br/>
              +20% more cook time per kg vs traditional LPG
            </div>
          </div>
        </div>

        {/* Calculator */}
        <SectionLabel>💡 Monthly Cost Estimate</SectionLabel>
        <Card style={{ marginBottom:22 }}>
          <div style={{ display:'flex', gap:12, marginBottom:14 }}>
            <div style={{ flex:1 }}>
              <label style={{ ...lbl, color:'var(--ink50)', fontSize:12 }}>Kg/month (traditional)</label>
              <input type="number" value={kg} min={1} max={200}
                onChange={e => setKg(Math.max(1, parseFloat(e.target.value)||1))}
                style={inp}
                onFocus={e => { e.target.style.borderColor='var(--g500)'; e.target.style.background='#fff' }}
                onBlur={e =>  { e.target.style.borderColor='var(--g100)'; e.target.style.background='var(--g50)' }}
              />
            </div>
            <div style={{ flex:1 }}>
              <label style={{ ...lbl, color:'var(--ink50)', fontSize:12 }}>Household size</label>
              <select onChange={e => setKg({'1':6,'2':12,'3':22}[e.target.value])}
                style={{ ...inp, cursor:'pointer' }}>
                <option value="1">1–2 people</option>
                <option value="2">3–5 people</option>
                <option value="3">6+ people</option>
              </select>
            </div>
          </div>
          <div style={{ background:'var(--g50)', border:'1px solid var(--g100)', borderRadius:12, padding:'14px 16px', marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <span style={{ fontSize:13, color:'var(--ink50)' }}>Est. monthly cost with Trashformas</span>
              <span style={{ fontFamily:'var(--ff-display)', fontSize:20, fontWeight:900, color:'var(--g800)' }}>₦{monthlyCost.toLocaleString()}</span>
            </div>
          </div>
          <div style={{ fontSize:12, color:'var(--ink50)', lineHeight:1.6 }}>
            💡 With +20% cook-time efficiency, <strong>{kg}kg</strong> of Trashformas biogas
            cooks as much as <strong>~{equivalentLPG}kg</strong> of traditional LPG.
          </div>
        </Card>

        {/* Form */}
        <SectionLabel>📋 Your Details</SectionLabel>
        <Card>

          {/* Name */}
          <div style={{ marginBottom:16 }}>
            <label style={lbl}>Full Name <span style={{ color:'#e53935' }}>*</span></label>
            <input type="text" value={form.name} onChange={e => set('name', e.target.value)}
              placeholder="e.g. Amara Okafor" style={inp}
              onFocus={e => { e.target.style.borderColor='var(--g500)'; e.target.style.background='#fff' }}
              onBlur={e =>  { e.target.style.borderColor='var(--g100)'; e.target.style.background='var(--g50)' }}
            />
          </div>

          {/* Email */}
          <div style={{ marginBottom:16 }}>
            <label style={lbl}>Email Address <span style={{ color:'#e53935' }}>*</span></label>
            <input type="email" value={form.email} onChange={e => set('email', e.target.value)}
              placeholder="you@example.com" style={inp}
              onFocus={e => { e.target.style.borderColor='var(--g500)'; e.target.style.background='#fff' }}
              onBlur={e =>  { e.target.style.borderColor='var(--g100)'; e.target.style.background='var(--g50)' }}
            />
          </div>

          {/* WhatsApp */}
          <div style={{ marginBottom:16 }}>
            <label style={lbl}>WhatsApp Number <span style={{ color:'#e53935' }}>*</span></label>
            <div style={{ display:'flex' }}>
              <div style={{ display:'flex', alignItems:'center', gap:5, background:'var(--g50)', border:'1.5px solid var(--g100)', borderRight:'none', borderRadius:'10px 0 0 10px', padding:'13px 12px', fontSize:13.5, fontWeight:600, color:'var(--g800)', whiteSpace:'nowrap', flexShrink:0 }}>
                🇳🇬 +234
              </div>
              <input type="tel" value={form.whatsapp}
                onChange={e => set('whatsapp', e.target.value.replace(/\D/g,''))}
                placeholder="8012345678" maxLength={11}
                style={{ ...inp, borderRadius:'0 10px 10px 0', flex:1, minWidth:0 }}
                onFocus={e => { e.target.style.borderColor='var(--g500)' }}
                onBlur={e =>  { e.target.style.borderColor='var(--g100)' }}
              />
            </div>
            <div style={{ fontSize:11.5, color:'var(--ink50)', marginTop:5 }}>💬 We'll confirm your spot via WhatsApp</div>
          </div>

          {/* Location */}
          <div style={{ marginBottom:16 }}>
            <label style={lbl}>Location / City <span style={{ color:'#e53935' }}>*</span></label>
            <input type="text" value={form.location} onChange={e => set('location', e.target.value)}
              placeholder="e.g. Lagos, Abuja, Port Harcourt…" style={inp}
              onFocus={e => { e.target.style.borderColor='var(--g500)'; e.target.style.background='#fff' }}
              onBlur={e =>  { e.target.style.borderColor='var(--g100)'; e.target.style.background='var(--g50)' }}
            />
          </div>

          {/* Gas usage */}
          <div style={{ marginBottom:16 }}>
            <label style={lbl}>Estimated Monthly Gas Usage</label>
            <select value={form.usage} onChange={e => set('usage', e.target.value)}
              style={{ ...inp, cursor:'pointer', appearance:'none', backgroundImage:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%232e8b2e' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`, backgroundRepeat:'no-repeat', backgroundPosition:'right 14px center', paddingRight:36 }}>
              <option value="">Select usage bracket</option>
              <option value="1-5kg">1–5 kg/month (small household)</option>
              <option value="6-12kg">6–12 kg/month (medium household)</option>
              <option value="13-20kg">13–20 kg/month (large household)</option>
              <option value="20+kg">20+ kg/month (commercial / large)</option>
            </select>
          </div>

          {/* Source */}
          <div style={{ marginBottom:22 }}>
            <label style={lbl}>How did you hear about us?</label>
            <select value={form.source} onChange={e => set('source', e.target.value)}
              style={{ ...inp, cursor:'pointer', appearance:'none', backgroundImage:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%232e8b2e' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`, backgroundRepeat:'no-repeat', backgroundPosition:'right 14px center', paddingRight:36 }}>
              <option value="">Select an option</option>
              {['Social media','Friend / Family','WhatsApp group','News article','Other'].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>

          <PrimaryBtn onClick={handleSubmit} loading={loading}>
            🚀 Join the Waitlist
          </PrimaryBtn>

          <p style={{ textAlign:'center', fontSize:12, color:'var(--ink50)', marginTop:14, lineHeight:1.6 }}>
            🔒 Your info is private and only used to notify you about Trashformas.
          </p>
        </Card>
      </div>

      <Toast msg={toast} />
    </div>
  )
}
